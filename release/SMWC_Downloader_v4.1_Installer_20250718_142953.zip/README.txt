SMWCentral Downloader & Patcher v4.1

INSTALLATION INSTRUCTIONS:
1. Extract both files to the same folder
2. Run "SMWC Downloader.exe" to start the application
3. DO NOT run "SMWC Updater.exe" directly - it's used automatically for updates

WHAT'S NEW IN v4.1:
� Fixed PyInstaller update restart mechanism
� Added standalone updater to prevent Python DLL errors
� Improved update process reliability
� Enhanced error handling during updates

IMPORTANT NOTES:
� Both executables must be in the same folder for updates to work
� The updater runs automatically when you update the application
� You only need to run "SMWC Downloader.exe" to start the program

For support, visit: https://github.com/iamtheratio/SMWCentral-Downloader---Patcher
